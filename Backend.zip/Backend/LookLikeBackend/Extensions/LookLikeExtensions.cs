﻿using LookLike.Backend.Context;
using LookLike.Backend.Repos;
using LookLike.Shared.Assemblers;
using Microsoft.EntityFrameworkCore;

namespace LookLike.Backend.Extensions
{
    public static class LookLikeExtensions
    {
        public static void AddBackend(this IServiceCollection services)
        {
            services.ConfigureCors();
            services.ConfigureInMemoryContext();
            services.ConfigureRepoService();
            services.ConfigureAssamblers();
        }

        private static void ConfigureCors(this IServiceCollection services)
        {

            services.AddCors(option =>
                 option.AddPolicy(name: "LookLikeCors",
                     policy =>
                     {
                         policy.WithOrigins("https://localhost:7020/")
                         .AllowAnyHeader()
                         .AllowAnyMethod();
                     }
                 )
            );
        }

        private static void ConfigureInMemoryContext(this IServiceCollection services)
        {
            string dbNameInMemoryContext = "LookLike" + Guid.NewGuid();
            services.AddDbContext<LookLikeInMemoryContext>
            (
                 options => options.UseInMemoryDatabase(databaseName: dbNameInMemoryContext),
                 ServiceLifetime.Scoped,
                 ServiceLifetime.Scoped
            );
        }

        private static void ConfigureRepoService(this IServiceCollection services)
        {
            //services.AddScoped<ISpecialistRepo, SpecialistRepo<LookLikeInMemoryContext>>();
            //services.AddScoped<IProfessionRepo, ProfessionRepo<LookLikeInMemoryContext>>();
            //services.AddScoped<IUserRepo, UserRepo<LookLikeInMemoryContext>>();
            services.AddScoped<IAdminRepo, AdminRepo<LookLikeInMemoryContext>>();
        }

        private static void ConfigureAssamblers(this IServiceCollection services)
        {
            //services.AddScoped<ProfessionAssambler>();
            //services.AddScoped<SpecialistAssambler>();
            //services.AddScoped<UserAssambler>();
            services.AddScoped<AdminAssembler>();
        }

    }
}
