﻿//using LookLike.Backend.Context;
//using LookLike.Shared.Models;
//using Microsoft.EntityFrameworkCore;
//using LookLike.Backend.Repos;
//using LookLike.Backend.Repos.Base;
//using ServiceProvider = LookLike.Shared.Models.ServiceProvider;


//namespace LookLike.Backend.Repos
//{
//    public class ServiceProviderRepo<TDbContext> : BaseRepo<TDbContext, ServiceProvider>, IServiceProviderRepo where TDbContext : LookLikeContext
//    {
//        public ServiceProviderRepo(TDbContext? dbContext) : base(dbContext)
//        {
//        }
//    }
//}