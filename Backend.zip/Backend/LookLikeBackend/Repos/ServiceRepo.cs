﻿//using LookLike.Backend.Context;
//using LookLike.Shared.Models;
//using Microsoft.EntityFrameworkCore;
//using LookLike.Backend.Repos;
//using LookLike.Backend.Repos.Base;


//namespace LookLike.Backend.Repos
//{
//    public class ServiceRepo<TDbContext> : BaseRepo<TDbContext, Service>, IServiceRepo where TDbContext : LookLikeContext
//    {
//        public ServiceRepo(TDbContext? dbContext) : base(dbContext)
//        {
//        }
//    }
//}