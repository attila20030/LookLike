﻿//using LookLike.Backend.Repos.Base;
//using LookLike.Shared.Models;

//namespace LookLike.Backend.Repos
//{
//    public interface IBookingRepo : IBaseRepo<Booking>
//    {
//    }
//}