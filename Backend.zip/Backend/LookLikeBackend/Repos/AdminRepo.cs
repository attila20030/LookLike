﻿using LookLike.Backend.Context;
using LookLike.Shared.Models;
using Microsoft.EntityFrameworkCore;
using LookLike.Backend.Repos;
using LookLike.Backend.Repos.Base;


namespace LookLike.Backend.Repos
{
    public class AdminRepo<TDbContext> : BaseRepo<TDbContext, Admin>, IAdminRepo where TDbContext : LookLikeContext
    {
        public AdminRepo(TDbContext? dbContext) : base(dbContext)
        {
        }

        public async Task<Admin> GetUserByNameAsync(string Username)
        {
            //return (await FindByConditionAsync(student => student.FirstName == firstName && student.LastName == lastName)).FirstOrDefault() ?? new Student();
            return await _dbSet!.FindByCondition<Admin>(a => a.Username == Username).FirstOrDefaultAsync() ?? new Admin();
        }
    }
}
