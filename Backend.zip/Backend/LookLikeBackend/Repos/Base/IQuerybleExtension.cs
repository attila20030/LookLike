﻿using System.Linq.Expressions;

namespace LookLike.Backend.Repos.Base
{
    public static class IQuerybleExtension
    {
        public static IQueryable<TEntity> FindByCondition<TEntity>(this IQueryable<TEntity> query, Expression<Func<TEntity, bool>> expression) => query.Where(expression);
    }
}
