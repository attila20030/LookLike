﻿//using LookLike.Backend.Context;
//using LookLike.Shared.Models;
//using Microsoft.EntityFrameworkCore;
//using LookLike.Backend.Repos;
//using LookLike.Backend.Repos.Base;


//namespace LookLike.Backend.Repos
//{
//    public class CategoryRepo<TDbContext> : BaseRepo<TDbContext, Category>, ICategoryRepo where TDbContext : LookLikeContext
//    {
//        public CategoryRepo(TDbContext? dbContext) : base(dbContext)
//        {
//        }
//    }
//}