﻿//using LookLike.Backend.Repos.Base;
//using LookLike.Shared.Models;
//using ServiceProvider = LookLike.Shared.Models.ServiceProvider;

//namespace LookLike.Backend.Repos
//{
//    public interface IServiceProviderRepo : IBaseRepo<ServiceProvider>
//    {
//    }
//}