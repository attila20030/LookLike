﻿//using LookLike.Backend.Context;
//using LookLike.Shared.Models;
//using Microsoft.EntityFrameworkCore;
//using LookLike.Backend.Repos;
//using LookLike.Backend.Repos.Base;


//namespace LookLike.Backend.Repos
//{
//    public class UserRepo<TDbContext> : BaseRepo<TDbContext, User>, IUserRepo where TDbContext : LookLikeContext
//    {
//        public UserRepo(TDbContext? dbContext) : base(dbContext)
//        {
//        }

//        public async Task<User> GetUserByNameAsync(string Username)
//        {
//            //return (await FindByConditionAsync(student => student.FirstName == firstName && student.LastName == lastName)).FirstOrDefault() ?? new Student();
//            return await _dbSet!.FindByCondition<User>(u => u.Username == Username).FirstOrDefaultAsync() ?? new User();
//        }
//    }
//}
