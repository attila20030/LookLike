﻿//namespace LookLike.Backend.Repos.Managers
//{
//    public interface IRepositoryManager
//    {
//        public ISpecialistRepo? SpecialistRepo { get; }
//        public IProfessionRepo? ProfessionRepo { get; }
//        public IUserRepo? UserRepo { get; }
//    }
//}
