﻿//namespace LookLike.Backend.Repos.Managers
//{
//    public class RepositoryManager : IRepositoryManager
//    {
//        private IProfessionRepo? _professionRepo;
//        private ISpecialistRepo? _specialistRepo;
//        private IUserRepo? _userRepo;

//        public RepositoryManager(IProfessionRepo? professionRepo, ISpecialistRepo? specialistRepo, IUserRepo? userRepo)
//        {
//            _professionRepo = professionRepo;
//            _specialistRepo = specialistRepo;
//            _userRepo = userRepo;
//        }

//        public IProfessionRepo? ProfessionRepo => _professionRepo;
//        public ISpecialistRepo? SpecialistRepo => _specialistRepo;
//        public IUserRepo? UserRepo => _userRepo;

//    }
//}
