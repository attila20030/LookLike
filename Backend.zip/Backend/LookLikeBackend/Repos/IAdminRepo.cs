﻿using LookLike.Backend.Repos.Base;
using LookLike.Shared.Models;

namespace LookLike.Backend.Repos
{
    public interface IAdminRepo : IBaseRepo<Admin>
    {
        public Task<Admin> GetUserByNameAsync(string Username);
    }
}
