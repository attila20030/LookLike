﻿//using LookLike.Backend.Context;
//using LookLike.Shared.Models;
//using Microsoft.EntityFrameworkCore;
//using LookLike.Backend.Repos;
//using LookLike.Backend.Repos.Base;


//namespace LookLike.Backend.Repos
//{
//    public class BookingRepo<TDbContext> : BaseRepo<TDbContext, Booking>, IBookingRepo where TDbContext : LookLikeContext
//    {
//        public BookingRepo(TDbContext? dbContext) : base(dbContext)
//        {
//        }
//    }
//}