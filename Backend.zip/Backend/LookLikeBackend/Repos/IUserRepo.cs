﻿//using LookLike.Backend.Repos.Base;
//using LookLike.Shared.Models;

//namespace LookLike.Backend.Repos
//{
//    public interface IUserRepo : IBaseRepo<User>
//    {
//        public Task<User> GetUserByNameAsync(string Username);
//    }
//}
