﻿namespace LookLike.Backend.Services
{
    public interface IAdminService
    {
    }
}
