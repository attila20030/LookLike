﻿//using LookLike.Backend.Repos.Managers;

//namespace LookLike.Backend.Services
//{
//    public class UserService : IUserService
//    {
//        private readonly IRepositoryManager _repositoryManager;

//        public UserService(IRepositoryManager repositoryManager)
//        {
//            _repositoryManager = repositoryManager;
//        }
//    }
//}
