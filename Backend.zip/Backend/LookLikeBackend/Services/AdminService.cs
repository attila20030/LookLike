﻿

namespace LookLike.Backend.Services
{
    public class AdminService : IAdminService
    {
        //private readonly IRepositoryManager _repositoryManager;

        public AdminService()
        {
            //_repositoryManager = repositoryManager;
        }
    }
}
