﻿using Microsoft.EntityFrameworkCore;

namespace LookLike.Backend.Context
{
    public class LookLikeInMemoryContext : LookLikeContext
    {
        public LookLikeInMemoryContext(DbContextOptions<LookLikeInMemoryContext> options) : base(options)
        {

        }


    }
}