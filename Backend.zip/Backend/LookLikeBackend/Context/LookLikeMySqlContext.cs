﻿using Microsoft.EntityFrameworkCore;

namespace LookLike.Backend.Context
{
    public class LookLikeMySqlContext : LookLikeContext
    {
        public LookLikeMySqlContext(DbContextOptions<LookLikeMySqlContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Seed();
            base.OnModelCreating(modelBuilder);
        }
    }
}
