﻿using LookLike.Backend.Context;
using LookLike.Shared.Models;
using Microsoft.EntityFrameworkCore;

namespace LookLike.Backend.Context
{
    public class LookLikeContext : DbContext
    {
        public DbSet<Admin> Admins { get; set; }
        //public DbSet<Booking> Bookings { get; set; }
        //public DbSet<Category> Categories { get; set; }
        //public DbSet<Service> Services { get; set; }
        //public DbSet<Shared.Models.ServiceProvider> ServiceProviders { get; set; }
        //public DbSet<User> Users { get; set; }

        public LookLikeContext(DbContextOptions options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Seed();
            base.OnModelCreating(modelBuilder);
        }

    }
}
