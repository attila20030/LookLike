﻿using LookLike.Shared.Models;
using Microsoft.EntityFrameworkCore;



namespace LookLike.Backend.Context
{
    public static class ModelBuilderExtension
    {
        public static void Seed(this ModelBuilder modelBuilder)
        {
            List<Admin> admins = new List<Admin>
            {
                new Admin
                {
                    Id=Guid.NewGuid(),
                    Username="Rebechaaa",
                    Password="StoleYourHeart",
                    Name="Kristofer",
                    Email="NobodyNose@gmail.com",
                    BirthDay = DateTime.Now
                },
                new Admin
                {
                    Id=Guid.NewGuid(),
                    Username="CrunchyCat3",
                    Password="Meow",
                    Name="Robertho",
                    Email="SomeBody@gmail.com",
                    BirthDay = DateTime.Now
                }
            };
            //List<Booking> bookings = new List<Booking>
            //{
            //    new Booking
            //    {
            //          ServiceProviderId = Guid.NewGuid(),
            //          Id = Guid.NewGuid(),
            //          DateOfReservation = DateTime.Now,
            //          Date = DateTime.Now,
            //          Status = string.Empty
            //     },
            //    new Booking
            //    {
            //          ServiceProviderId = Guid.NewGuid(),
            //          Id = Guid.NewGuid(),
            //          DateOfReservation = DateTime.Now,
            //          Date = DateTime.Now,
            //          Status = string.Empty,
            //    },
            //};

            //List<Category> categories = new List<Category>
            //{
            //     new Category
            //     {
            //          CategoryId = 0,
            //          ServiceProviderId = 0,
            //          CategoryName = string.Empty
            //     },
            //    new Category
            //    {
            //          CategoryId = 0,
            //          ServiceProviderId = 0,
            //          CategoryName = string.Empty
            //    },
            //};

            //List<Service> services = new List<Service>
            //{
            //     new Service
            //     {
            //         Id = Guid.NewGuid(),
            //         UserId = Guid.NewGuid(),
            //         Rate = 0,
            //         Text = string.Empty,
            //         Price = 0,
            //         BookingDate = DateTime.Now,
            //         BookingResevation = DateTime.Now,
            //     },
            //    new Service
            //    {
            //         Id = Guid.NewGuid(),
            //         UserId = Guid.NewGuid(),
            //         Rate = 0,
            //         Text = string.Empty,
            //         Price = 0,
            //         BookingDate = DateTime.Now,
            //         BookingResevation = DateTime.Now,
            //    }
            //};

            //List<ServiceProvider> serviceProviders = new List<ServiceProvider>
            //{
            //     new ServiceProvider
            //     {
            //         Id = Guid.NewGuid(),
            //         Email = string.Empty,
            //         QualificationLevel = string.Empty,
            //         UserName = string.Empty,
            //         Bio = string.Empty,
            //         Password = string.Empty,
            //     },
            //    new ServiceProvider
            //    {
            //        Id = Guid.NewGuid(),
            //        Email = string.Empty,
            //        QualificationLevel = string.Empty,
            //        UserName = string.Empty,
            //        Bio = string.Empty,
            //        Password = string.Empty,
            //    }
            //};
            //List<User> users = new List<User>
            //{
            //    new User
            //    {
            //        Id=Guid.NewGuid(),
            //        Username="Rebechaaa",
            //        Password="StoleYourHeart",
            //        Name="Kristofer",
            //        Email="NobodyNose@gmail.com"
            //    },
            //    new User
            //    {
            //        Id=Guid.NewGuid(),
            //        Username="CrunchyCat3",
            //        Password="Meow",
            //        Name="Robertho",
            //        Email="SomeBody@gmail.com"
            //    }
            //};
            modelBuilder.Entity<Admin>().HasData(admins);
            //modelBuilder.Entity<Booking>().HasData(bookings);
            //modelBuilder.Entity<Category>().HasData(categories);
            //modelBuilder.Entity<Service>().HasData(services);
            //modelBuilder.Entity<ServiceProvider>().HasData(serviceProviders);
            //modelBuilder.Entity<User>().HasData(users);
        }
    }
}