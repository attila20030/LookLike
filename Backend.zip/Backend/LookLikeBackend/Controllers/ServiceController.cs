﻿//using LookLike.Backend.Repos;
//using LookLike.Shared.Dtos;
//using Microsoft.AspNetCore.Mvc;
//using LookLike.Shared.Models;
//using LookLike.Backend.Controllers.Base;
//using LookLike.Shared.Assemblers;


//namespace LookLike.Backend.Controllers
//{
//    [ApiController]
//    [Route("api/[controller]")]
//    public class ServiceController : BaseController<Service, ServiceDto>
//    {
//        private IServiceRepo _serviceRepo;

//        public ServiceController(ServiceAssambler? assambler, IServiceRepo? repo) : base(assambler, repo)
//        {
//            _serviceRepo = repo ?? throw new ArgumentNullException(nameof(repo));
//        }
//    }
//}