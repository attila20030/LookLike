﻿using LookLike.Backend.Repos.Base;
using LookLike.shared.Models;
using LookLike.shared.Responses;
using LookLike.Shared.Assemblers;
using Microsoft.AspNetCore.Mvc;

namespace LookLike.Backend.Controllers.Base
{
    public abstract class BaseController<TModel, TDto> : ControllerBase 
        where TModel : class, IDbEntity<TModel>, new() 
        where TDto : class, new()
    {
        protected Assembler<TModel, TDto> _assambler;
        protected IBaseRepo<TModel> _repo;

        public BaseController(Assembler<TModel, TDto>? assembler, IBaseRepo<TModel>? repo)
        {
            _assambler= assembler ?? throw new ArgumentNullException(nameof(assembler));
            _repo = repo ?? throw new ArgumentNullException(nameof(repo));
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetByIdAsync(Guid id)
        {
            var entity = (await _repo.FindByConditionAsync(e => e.Id == id)).FirstOrDefault();
            if (entity != null)
                return Ok(_assambler.ToDto(entity));
            return NotFound();
        }

        [HttpGet]
        public async Task<IActionResult> GetAllAsync()
        {
            var entities = (await _repo.GetAllAsync()).ToList();
            return Ok(entities.Select(e => _assambler.ToDto(e)));
        }

        [HttpPut()]
        public async Task<ActionResult> UpdateAsync(TDto entitieDto)
        {
            ControllerResponse response = response = await _repo.UpdateAsync(_assambler.ToModel(entitieDto));
            if (response.HasError)
            {
                Console.WriteLine(response.Error);
                response.ClearAndAddError("Az entitás adataina módósítása nem sikerült!");
                return BadRequest(response);
            }
            return Ok(response);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAsync(Guid id)
        {
            ControllerResponse response = response = await _repo.DeleteAsync(id);
            if (response.HasError) 
            {
                Console.WriteLine(response.Error);
                response.ClearAndAddError("Az entitás adatainek törlése nem sikerült!");
                return BadRequest(response);
            }
            return Ok(response);
        }

        [HttpPost()]
        public async Task<IActionResult> CreateAsync(TDto entitieDto)
        {
            ControllerResponse response = response = await _repo.CreateAsync(_assambler.ToModel(entitieDto));
            if(response.HasError)
            {
                Console.WriteLine(response.Error);
                response.ClearAndAddError("Új entitás adatának felvétele nem sikerült!");
                return BadRequest(response);
            }
            return Ok(response);
        }
    }
}
