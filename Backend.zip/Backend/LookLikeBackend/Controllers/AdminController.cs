﻿

using LookLike.Backend.Controllers.Base;
using LookLike.Backend.Repos;
using LookLike.Shared.Assemblers;
using LookLike.Shared.Dtos;
using LookLike.Shared.Models;
using Microsoft.AspNetCore.Mvc;

namespace LookLike.Backend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AdminController : BaseController<Admin, AdminDto>
    {
        private IAdminRepo _adminRepo;

        public AdminController(AdminAssembler? assambler, IAdminRepo? repo) : base(assambler, repo)
        {
            _adminRepo = repo ?? throw new ArgumentNullException(nameof(repo));
        }

        [HttpGet("UserByName")]
        public async Task<IActionResult> GetUserByNameAsync([FromQuery] AdminDto adminDto)
        {
            Admin result = await _adminRepo.GetUserByNameAsync(adminDto.Username);
            return Ok(result);
        }
    }
}
