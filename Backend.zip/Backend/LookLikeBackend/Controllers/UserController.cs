﻿//using LookLike.Backend.Repos;
//using LookLike.Shared.Dtos;
//using Microsoft.AspNetCore.Mvc;
//using LookLike.Shared.Models;
//using LookLike.Backend.Controllers.Base;
//using LookLike.Shared.Assemblers;


//namespace LookLike.Backend.Controllers
//{
//    [ApiController]
//    [Route("api/[controller]")]
//    public class UserController : BaseController<User, UserDto>
//    {
//       private IUserRepo _userRepo;

//        public UserController(UserAssambler? assambler, IUserRepo? repo) : base(assambler, repo) 
//        {
//            _userRepo = repo ?? throw new ArgumentNullException(nameof(repo));
//        }

//        [HttpGet("UserByName")]
//        public async Task<IActionResult> GetUserByNameAsync([FromQuery] UserDto userDto)
//        {
//            User result = await _userRepo.GetUserByNameAsync(userDto.Username);
//            return Ok(result);
//        }
//    }
//}
