﻿//using LookLike.Backend.Controllers.Base;
//using LookLike.Shared.Assemblers;
//using LookLike.Shared.Dtos;
//using LookLike.Shared.Models;
//using Microsoft.AspNetCore.Mvc;

//namespace LookLike.Backend.Controllers
//{
//    [ApiController]
//    [Route("api/[controller]")]
//    public class CategoryController : BaseController<Category, CategoryDto>
//    {
//        private ICategoryRepo _categoryRepo;

//        public CategoryController(CategoryAssambler? assambler, ICategoryRepo? repo) : base(assambler, repo)
//        {
//            _categoryRepo = repo ?? throw new ArgumentNullException(nameof(repo));
//        }
//    }
//}