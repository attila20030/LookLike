﻿//using LookLike.Backend.Repos;
//using LookLike.Shared.Dtos;
//using Microsoft.AspNetCore.Mvc;
//using LookLike.Shared.Models;
//using LookLike.Backend.Controllers.Base;
//using LookLike.Shared.Assemblers;
//using ServiceProvider = LookLike.Shared.Models.ServiceProvider;


//namespace LookLike.Backend.Controllers
//{
//    [ApiController]
//    [Route("api/[controller]")]
//    public class ServiceProviderController : BaseController<ServiceProvider, ServiceProviderDto>
//    {
//        private IServiceProviderRepo _serviceProviderRepo;

//        public ServiceProviderController(ServiceProviderAssambler? assambler, IServiceProviderRepo? repo) : base(assambler, repo)
//        {
//            _serviceProviderRepo = repo ?? throw new ArgumentNullException(nameof(repo));
//        }
//    }
//}