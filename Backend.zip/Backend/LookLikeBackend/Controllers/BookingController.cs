﻿//using LookLike.Backend.Controllers.Base;
//using LookLike.Backend.Repos;
//using LookLike.Shared.Assemblers;
//using LookLike.Shared.Dtos;
//using LookLike.Shared.Models;
//using Microsoft.AspNetCore.Mvc;

//namespace LookLike.Backend.Controllers
//{
//    [ApiController]
//    [Route("api/[controller]")]
//    public class BookingController : BaseController<Booking, BookingDto>
//    {
//        private IBookingRepo _bookingRepo;

//        public BookingController(BookingAssambler? assambler, IBookingRepo? repo) : base(assambler, repo)
//        {
//            _bookingRepo = repo ?? throw new ArgumentNullException(nameof(repo));
//        }
//    }
//}