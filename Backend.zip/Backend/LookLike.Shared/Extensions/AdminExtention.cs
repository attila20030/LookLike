﻿using LookLike.Shared.Dtos;
using LookLike.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LookLike.Shared.Extensions
{
    public static class AdminExtention
    {
        public static AdminDto ToDto(this Admin admin)
        {
            return new AdminDto
            {
                Id = admin.Id,
                Username = admin.Username,
                Password = admin.Password,
                Name = admin.Name,
                Email = admin.Email,
                BirthDay = admin.BirthDay,
            };
        }

        public static Admin ToModel(this AdminDto admindto)
        {
            return new Admin
            {
                Id = admindto.Id,
                Username = admindto.Username,
                Password = admindto.Password,
                Name = admindto.Name,
                Email = admindto.Email,
                BirthDay = admindto.BirthDay,
            };
        }

    }
}
