﻿//using LookLike.Shared.Dtos;
//using LookLike.Shared.Models;

//namespace LookLike.Shared.Extensions
//{
//    public static class CategoryExtention
//    {
//        public static CategoryDto ToDto(this Category category)
//        {
//            return new CategoryDto
//            {
//                CategoryId = category.CategoryId,
//                CategoryName = category.CategoryName,
//                ServiceProviderId = category.ServiceProviderId,
//            };
//        }

//        public static Category ToModel(this CategoryDto categoryDto)
//        {
//            return new Category
//            {
//                CategoryId = categoryDto.CategoryId,
//                CategoryName = categoryDto.CategoryName,
//                ServiceProviderId = categoryDto.ServiceProviderId,
//            };
//        }
//    }
//}
