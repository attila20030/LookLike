﻿//using LookLike.Shared.Dtos;
//using LookLike.Shared.Models;

//namespace LookLike.Shared.Extensions
//{
//    public static class ServiceExtension
//    {
//        public static ServiceDto ToDto(this Service service)
//        {
//            return new ServiceDto
//            {
//                Id = service.Id,
//                UserId = service.UserId,
//                Rate = service.Rate,
//                Text = service.Text,
//                Price = service.Price,
//                BookingDate = service.BookingDate,
//                BookingResevation = service.BookingResevation,
//            };
//        }

//        public static Service ToModel(this ServiceDto serviceDto)
//        {
//            return new Service
//            {
//                Id = serviceDto.Id,
//                UserId = serviceDto.UserId,
//                Rate = serviceDto.Rate,
//                Text = serviceDto.Text,
//                Price = serviceDto.Price,
//                BookingDate = serviceDto.BookingDate,
//                BookingResevation = serviceDto.BookingResevation,
//            };
//        }
//    }
//}
