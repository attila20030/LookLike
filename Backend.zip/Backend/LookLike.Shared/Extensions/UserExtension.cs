﻿//using LookLike.Shared.Dtos;
//using LookLike.Shared.Models;

//namespace LookLike.Shared.Extensions
//{
//    public static class UserExtension
//    {
//        public static UserDto ToDto(this User user)
//        {
//            return new UserDto
//            {
//                Id = user.Id,
//                Username = user.Username,
//                Password = user.Password,
//                Name = user.Name,
//                Email = user.Email,
//            };
//        }

//        public static User ToModel(this UserDto userdto)
//        {
//            return new User
//            {
//                Id = userdto.Id,
//                Username = userdto.Username,
//                Password = userdto.Password,
//                Name = userdto.Name,
//                Email = userdto.Email,
//            };
//        }
//    }
//}
