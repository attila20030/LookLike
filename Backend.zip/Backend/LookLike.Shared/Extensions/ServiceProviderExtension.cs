//using LookLike.Shared.Dtos;
//using LookLike.Shared.Models;

//namespace LookLike.Shared.Extensions
//{
//    public static class ServiceProviderExtension
//    {
//        public static ServiceProviderDto ToDto(this ServiceProvider serviceProvider)
//        {
//            return new ServiceProviderDto
//            {
//                Id = serviceProvider.Id,
//                Email = serviceProvider.Email,
//                QualificationLevel = serviceProvider.QualificationLevel,
//                UserName = serviceProvider.UserName,
//                Bio = serviceProvider.Bio,
//                Password = serviceProvider.Password,
//            };
//        }

//        public static ServiceProvider ToModel(this ServiceProviderDto serviceProviderDto)
//        {
//            return new ServiceProvider
//            {
//                Id = serviceProviderDto.Id,
//                Email = serviceProviderDto.Email,
//                QualificationLevel = serviceProviderDto.QualificationLevel,
//                UserName = serviceProviderDto.UserName,
//                Bio = serviceProviderDto.Bio,
//                Password = serviceProviderDto.Password,
//            };
//        }
//    }

//}
