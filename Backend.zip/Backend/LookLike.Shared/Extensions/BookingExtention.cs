﻿//using LookLike.Shared.Dtos;
//using LookLike.Shared.Models;

//namespace LookLike.Shared.Extensions
//{
//    public static class BookingExtention
//    {
//        public static BookingDto ToDto(this Booking booking)
//        {
//            return new BookingDto
//            {
//                ServiceProviderId = booking.ServiceProviderId,
//                Id = booking.Id,
//                DateOfReservation = booking.DateOfReservation,
//                Date = booking.Date,
//                Status = booking.Status,
//            };
//        }

//        public static Booking ToModel(this BookingDto bookingDto)
//        {
//            return new Booking
//            {
//                ServiceProviderId = bookingDto.ServiceProviderId,
//                Id = bookingDto.Id,
//                DateOfReservation = bookingDto.DateOfReservation,
//                Date = bookingDto.Date,
//                Status = bookingDto.Status,
//            };
//        }
//    }
//}
