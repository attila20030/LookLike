//namespace LookLike.Shared.Dtos
//{
//    public class ServiceProviderDto
//    {
//        public Guid Id { get; set; }
//        public string Email { get; set; } = string.Empty;
//        public string QualificationLevel { get; set; } = string.Empty;
//        public string UserName { get; set; } = string.Empty;
//        public string Bio { get; set; } = string.Empty;
//        public string Password { get; set; } = string.Empty;
//    }
//}
