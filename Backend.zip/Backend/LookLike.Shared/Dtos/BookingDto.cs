﻿//namespace LookLike.Shared.Dtos
//{
//    public class BookingDto
//    {
//        public Guid ServiceProviderId { get; set; }
//        public Guid Id { get; set; }
//        public DateTime DateOfReservation { get; set; }
//        public DateTime Date { get; set; }
//        public string Status { get; set; } = string.Empty;
//    }
//}
