﻿//namespace LookLike.Shared.Dtos
//{
//    public class ServiceDto
//    {
//        public Guid Id { get; set; }
//        public Guid UserId { get; set; }
//        public byte Rate { get; set; }
//        public string Text { get; set; } = string.Empty;
//        public int Price { get; set; }
//        public DateTime BookingDate { get; set; }
//        public DateTime BookingResevation { get; set; }
//    }

//}
