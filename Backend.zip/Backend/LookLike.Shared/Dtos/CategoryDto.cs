﻿//namespace LookLike.Shared.Dtos
//{
//    public class CategoryDto
//    {
//        public int CategoryId { get; set; }
//        public int ServiceProviderId { get; set; }
//        public string CategoryName { get; set; } = string.Empty;
//    }
//}
