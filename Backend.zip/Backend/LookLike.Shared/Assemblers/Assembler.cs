﻿namespace LookLike.Shared.Assemblers
{
    public abstract class Assembler<Tmodel, TDto>
    {
        public abstract Tmodel ToModel(TDto dto);
        public abstract TDto ToDto(Tmodel domainEntity);
    }
}
