﻿//using LookLike.Shared.Dtos;
//using LookLike.Shared.Extensions;
//using LookLike.Shared.Models;

//namespace LookLike.Shared.Assemblers
//{
//    public class ServiceProviderAssambler : Assembler<ServiceProvider, ServiceProviderDto>
//    {
//        public override ServiceProviderDto ToDto(ServiceProvider domainEntity)
//        {
//            return domainEntity.ToDto();
//        }

//        public override ServiceProvider ToModel(ServiceProviderDto dto)
//        {
//            return dto.ToModel();
//        }
//    }
//}
