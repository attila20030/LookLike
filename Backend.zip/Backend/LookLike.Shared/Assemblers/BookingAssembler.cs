﻿//using LookLike.Shared.Dtos;
//using LookLike.Shared.Extensions;
//using LookLike.Shared.Models;



//namespace LookLike.Shared.Assemblers
//{
//    public class BookingAssambler : Assembler<Booking, BookingDto>
//    {
//        public override BookingDto ToDto(Booking domainEntity)
//        {
//            return domainEntity.ToDto();
//        }

//        public override Booking ToModel(BookingDto dto)
//        {
//            return dto.ToModel();
//        }
//    }
//}
