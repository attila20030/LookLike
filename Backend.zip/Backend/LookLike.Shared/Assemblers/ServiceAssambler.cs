﻿//using LookLike.Shared.Dtos;
//using LookLike.Shared.Extensions;
//using LookLike.Shared.Models;

//namespace LookLike.Shared.Assemblers
//{
//    public class ServiceAssambler : Assembler<Service, ServiceDto>
//    {
//        public override ServiceDto ToDto(Service domainEntity)
//        {
//            return domainEntity.ToDto();
//        }

//        public override Service ToModel(ServiceDto dto)
//        {
//            return dto.ToModel();
//        }
//    }
//}
