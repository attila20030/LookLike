﻿using LookLike.Shared.Dtos;
using LookLike.Shared.Extensions;
using LookLike.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LookLike.Shared.Assemblers
{
    public class AdminAssembler : Assembler<Admin, AdminDto>
    {
        public override AdminDto ToDto(Admin domainEntity)
        {
            return domainEntity.ToDto();
        }

        public override Admin ToModel(AdminDto dto)
        {
            return dto.ToModel();
        }
    }
}
