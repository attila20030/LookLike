﻿using LookLike.shared.Models;


namespace LookLike.Shared.Assemblers
{
    public class DefaultAssambler<TEntity, TEntityDto> : Assembler<TEntity, TEntityDto>
        where TEntity : class, IDbEntity<TEntity>, new()
        where TEntityDto : class, new()
    {
        public DefaultAssambler()
        {
        }
        public override TEntityDto ToDto(TEntity entity)
        {
            return new TEntityDto();
        }

        public override TEntity ToModel(TEntityDto dto)
        {
            return new TEntity();
        }
    }
}
