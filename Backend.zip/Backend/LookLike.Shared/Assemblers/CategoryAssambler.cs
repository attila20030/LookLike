﻿//using LookLike.Shared.Dtos;
//using LookLike.Shared.Extensions;
//using LookLike.Shared.Models;

//namespace LookLike.Shared.Assemblers
//{
//    public class CategoryAssambler : Assembler<Category, CategoryDto>
//    {
//        public override CategoryDto ToDto(Category domainEntity) 
//        {
//            return domainEntity.ToDto();
//        }

//        public override Category ToModel(CategoryDto dto)
//        {
//            return dto.ToModel();
//        }
//    }
//}
