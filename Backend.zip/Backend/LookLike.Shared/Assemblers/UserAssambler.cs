﻿//using LookLike.Shared.Dtos;
//using LookLike.Shared.Extensions;
//using LookLike.Shared.Models;

//namespace LookLike.Shared.Assemblers
//{
//    public class UserAssambler : Assembler<User, UserDto>
//    {
//        public override UserDto ToDto(User domainEntity)
//        {
//            return domainEntity.ToDto();
//        }

//        public override User ToModel(UserDto dto)
//        {
//            return dto.ToModel();
//        }
//    }
//}
