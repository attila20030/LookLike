﻿namespace LookLike.shared.Responses
{
    public class ControllerResponse : ErrorStore
    {
        public bool IsSucces => !HasError;

        public ControllerResponse() : base() { }
    }
}
