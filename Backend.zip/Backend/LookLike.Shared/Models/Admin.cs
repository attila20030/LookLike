﻿using LookLike.shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LookLike.Shared.Models
{
    public class Admin : IDbEntity<Admin>
    {
        public Admin()
        {
            Id = Guid.NewGuid();
            Username = string.Empty;
            Password = string.Empty;
            Name = string.Empty;
            Email = string.Empty;
            BirthDay = DateTime.Now;
        }

        public Admin(Guid userid, string username, string password, string name, string email, DateTime birthday)
        {
            Id = userid;
            Username = username;
            Password = password;
            Name = name;
            Email = email;
            BirthDay = birthday;
        }

        public Guid Id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public DateTime BirthDay { get; set; }  
        public bool HasId => Id != Guid.Empty;

        public override string ToString()
        {
            return $"{Username}";
        }
    }
}
