﻿//using LookLike.shared.Models;

//namespace LookLike.Shared.Models
//{
//    public class Booking : IDbEntity<Booking>    
//    {
//        public Booking()
//        {
//            ServiceProviderId = ServiceProviderId;
//            Id = Guid.NewGuid();
//            DateOfReservation = DateTime.Now;
//            Date = DateTime.Now;
//            Status = string.Empty;
//        }

//        public Booking(Guid serviceProviderId, Guid idopontId, DateTime dateOfReservation, DateTime date, string status)
//        {
//            ServiceProviderId = serviceProviderId;
//            Id = idopontId;
//            DateOfReservation = dateOfReservation;
//            Date = date;
//            Status = status;
//        }

//        public Guid ServiceProviderId { get; set; }
//        public Guid Id { get; set; }
//        public DateTime DateOfReservation { get; set; }
//        public DateTime Date { get; set; }
//        public string Status { get; set; } = string.Empty;
//    }
//}
