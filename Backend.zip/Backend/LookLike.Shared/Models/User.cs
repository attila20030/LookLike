﻿//using LookLike.shared.Models;

//namespace LookLike.Shared.Models
//{
//    public class User : IDbEntity<User>
//    {
//        public User()
//        {
//            Id = Guid.NewGuid();
//            Username = string.Empty;
//            Password = string.Empty;
//            Name = string.Empty;
//            Email = string.Empty;
//        }

//        public User(Guid userid, string username, string password, string name, string email)
//        {
//            Id = userid;
//            Username = username;
//            Password = password;
//            Name = name;
//            Email = email;
//        }

//        public Guid Id { get; set; }
//        public string Username { get; set; }
//        public string Password { get; set; }
//        public string Name { get; set; }
//        public string Email { get; set; }
//        public bool HasId => Id != Guid.Empty;

//        public override string ToString()
//        {
//            return $"{Username}";
//        }
//    }
//}
