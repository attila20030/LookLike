﻿//using LookLike.shared.Models;
//using LookLike.Shared.Enums;

//namespace LookLike.Shared.Models
//{
//    public class Category : IDbEntity<Category>
//    {
//        public Guid Id { get; set; }
//        public int CategoryId { get; set; }
//        public int ServiceProviderId { get; set; }
//        public string CategoryName { get; set; } = string.Empty;

//        public CategoryEnum EnumValue => (CategoryEnum)CategoryId;
//    }
//}
