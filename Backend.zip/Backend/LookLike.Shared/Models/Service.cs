﻿//using LookLike.shared.Models;

//namespace LookLike.Shared.Models
//{
//    public partial class Service : IDbEntity<Service>
//    {
//        public Service() 
//        {
//            Id = Guid.NewGuid();
//            UserId = Guid.NewGuid();
//            Rate = 0;
//            Text = string.Empty;
//            Price = 0;
//            BookingDate = DateTime.Now;
//            BookingResevation = DateTime.Now;
//        }

//        public Service(Guid serviceId, Guid userId, byte rate, string text, int price, DateTime bookingDate, DateTime bookingResevation)
//        {
//            Id = serviceId;
//            UserId = userId;
//            Rate = rate;
//            Text = text;
//            Price = price;
//            BookingDate = bookingDate;
//            BookingResevation = bookingResevation;
//        }

//        public Guid Id { get; set; }
//        public Guid UserId { get; set; }
//        public byte Rate { get; set; }
//        public string Text { get; set; } = string.Empty;
//        public int Price { get; set; }
//        public DateTime BookingDate { get; set; }
//        public DateTime BookingResevation { get; set; }

//        public override string ToString()
//        {
//            return base.ToString();
//        }
//    }
//}
