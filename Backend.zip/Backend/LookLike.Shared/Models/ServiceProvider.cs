﻿//using LookLike.shared.Models;

//namespace LookLike.Shared.Models
//{
//    public class ServiceProvider : IDbEntity<ServiceProvider>
//    {
//        public ServiceProvider()
//        {
//            Id = Guid.NewGuid();
//            Email = string.Empty;
//            QualificationLevel = string.Empty;
//            UserName = string.Empty;
//            Bio = string.Empty;
//            Password = string.Empty;
//        }

//        public ServiceProvider(Guid serviceProviderId, string email, string qualificationLevel, string userName, string bio, string password)
//        {
//            Id = serviceProviderId;
//            Email = email;
//            QualificationLevel = qualificationLevel;
//            UserName = userName;
//            Bio = bio;
//            Password = password;
//        }

//        public Guid Id { get; set; }
//        public string Email { get; set; } = string.Empty;
//        public string QualificationLevel { get; set; } = string.Empty;
//        public string UserName { get; set; } = string.Empty;
//        public string Bio { get; set; } = string.Empty;
//        public string Password { get; set; } = string.Empty;
//    }
//}
