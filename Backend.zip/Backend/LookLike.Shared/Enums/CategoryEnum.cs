﻿//namespace LookLike.Shared.Enums
//{
//    public enum CategoryEnum
//    {
//        TattooArtist = 1,
//        Peircing = 2,
//        HairDresser = 3,
//        NailArtist = 4,
//    }
//}
