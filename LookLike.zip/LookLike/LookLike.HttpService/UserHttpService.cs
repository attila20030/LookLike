﻿//using LookLike.HttpService.Base;
//using LookLike.Shared.Assemblers;
//using LookLike.Shared.Dtos;
//using LookLike.Shared.Models;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace LookLike.HttpService
//{
//    public class UserHttpService : BaseHttpService<User, UserDto>, IUserHttpService
//    {
//        public UserHttpService() { }

//        public UserHttpService(IHttpClientFactory? httpClientFactory, UserAssambler userAssambler) : base(httpClientFactory, userAssambler)
//        {

//        }
//    }
//}
