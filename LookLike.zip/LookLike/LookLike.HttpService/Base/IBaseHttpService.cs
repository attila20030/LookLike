﻿using LookLike.shared.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LookLike.HttpService.Base
{
    public interface IBaseHttpService<TModel>
    {
        Task<List<TModel>> GetAllAsync();
        Task<TModel> GetByIdAsync(Guid id);
        Task<ControllerResponse> CreateAsync(TModel user);
        Task<ControllerResponse> UpdateAsync(TModel user);
        Task<ControllerResponse> DeleteAsync(Guid id);
        public Task<ControllerResponse> InsertAsync(TModel entity);

    }
}
