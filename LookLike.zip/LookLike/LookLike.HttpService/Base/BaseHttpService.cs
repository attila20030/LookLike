﻿using LookLike.shared.Models;
using LookLike.shared.Responses;
using LookLike.Shared.Assemblers;
using Newtonsoft.Json;
using System.Diagnostics;
using System.Net;
using System.Net.Http.Json;

namespace LookLike.HttpService.Base
{
    public class BaseHttpService<TModel, TDto> : IBaseHttpService<TModel> where TModel : class, IDbEntity<TModel>, new() where TDto : class, new()
    {
        protected readonly HttpClient _httpClient;
        protected readonly Assembler<TModel, TDto> _assambler;

        protected string _apiName => typeof(TModel).Name;

        public BaseHttpService()
        {
            _httpClient = new HttpClient();
            _assambler = new DefaultAssambler<TModel, TDto>();
        }

        public BaseHttpService(IHttpClientFactory? httpClientFactory, Assembler<TModel, TDto> assembler)
        {
            if (assembler == null) throw new ArgumentNullException(nameof(assembler));
            if (httpClientFactory == null) throw new ArgumentNullException(nameof(httpClientFactory));
            _httpClient = httpClientFactory.CreateClient("LookLike");
            _assambler = assembler;
        }

        public async Task<List<TModel>> GetAllAsync()
        {
            try
            {
                List<TDto>? resultDto = await _httpClient.GetFromJsonAsync<List<TDto>>($"api/{_apiName}");
                if (resultDto == null)
                    return new List<TModel>();
                else
                    return resultDto.Select(dto => _assambler.ToModel(dto)).ToList();
            }
            catch (Exception ex)
            {
            }
            return new List<TModel>();
        }

        public Task<TModel> GetByIdAsync(Guid id)
        {
            throw new NotImplementedException();
        }

        public async Task<ControllerResponse> UpdateAsync(TModel entity)
        {
            ControllerResponse defaultResponse = new();
            try
            {
                HttpResponseMessage httpResponse = await _httpClient.PutAsJsonAsync($"api/{GetApiName()}", _assambler.ToDto(entity));
                if (httpResponse.StatusCode == HttpStatusCode.BadRequest)
                {
                    string content = await httpResponse.Content.ReadAsStringAsync();
                    ControllerResponse? response = JsonConvert.DeserializeObject<ControllerResponse>(content);
                    if (response is null)
                    {
                        defaultResponse.ClearAndAddError("A módosítás http kérés hibát okozott!");
                    }
                    else return response;
                }
                else if (!httpResponse.IsSuccessStatusCode)
                {
                    httpResponse.EnsureSuccessStatusCode();
                }
                else
                {
                    string content = await httpResponse.Content.ReadAsStringAsync();
                    ControllerResponse? response = JsonConvert.DeserializeObject<ControllerResponse>(content);
                    if (response is null)
                    {
                        defaultResponse.ClearAndAddError("A módosítás http kérés hibát okozott!");
                    }
                    else return response;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
            defaultResponse.ClearAndAddError("Az adatok frissítés nem lehetséges!");
            return defaultResponse;
        }


        public async Task<ControllerResponse> DeleteAsync(Guid id)
        {
            ControllerResponse defaultResponse = new();
            try
            {
                HttpResponseMessage httpResponse = await _httpClient.DeleteAsync($"api/{GetApiName()}/{id}");
                if (httpResponse.StatusCode == HttpStatusCode.BadRequest)
                {
                    string content = await httpResponse.Content.ReadAsStringAsync();
                    ControllerResponse? response = JsonConvert.DeserializeObject<ControllerResponse>(content);
                    if (response is null)
                    {
                        defaultResponse.ClearAndAddError("A törlés http kérés hibát okozott!");
                    }
                    else return response;
                }
                else if (!httpResponse.IsSuccessStatusCode)
                {
                    httpResponse.EnsureSuccessStatusCode();
                }
                else
                {
                    string content = await httpResponse.Content.ReadAsStringAsync();
                    ControllerResponse? response = JsonConvert.DeserializeObject<ControllerResponse>(content);
                    if (response is null)
                    {
                        defaultResponse.ClearAndAddError("A módosítás http kérés hibát okozott!");
                    }
                    else return response;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
            defaultResponse.ClearAndAddError("Az adatok törlése nem lehetséges!");
            return defaultResponse;
        }

        public async Task<ControllerResponse> InsertAsync(TModel entity)
        {
            ControllerResponse defaultResponse = new();
            try
            {
                HttpResponseMessage httpResponse = await _httpClient.PostAsJsonAsync($"api/{GetApiName()}", _assambler.ToDto(entity));
                if (httpResponse.StatusCode == HttpStatusCode.BadRequest)
                {
                    string content = await httpResponse.Content.ReadAsStringAsync();
                    ControllerResponse? response = JsonConvert.DeserializeObject<ControllerResponse>(content);
                    if (response is null)
                    {
                        defaultResponse.ClearAndAddError("A mentés http kérés hibát okozott!");
                    }
                    else return response;
                }
                else if (!httpResponse.IsSuccessStatusCode)
                {
                    httpResponse.EnsureSuccessStatusCode();
                }
                else
                {
                    string content = await httpResponse.Content.ReadAsStringAsync();
                    ControllerResponse? response = JsonConvert.DeserializeObject<ControllerResponse>(content);
                    if (response is null)
                    {
                        defaultResponse.ClearAndAddError("A módosítás http kérés hibát okozott!");
                    }
                    else return response;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }

            defaultResponse.ClearAndAddError("Az adatok mentése nem lehetséges!");
            return defaultResponse;
        }
        private static string GetApiName()
        {
            return new TModel().GetType().Name;
        }

        public Task<ControllerResponse> CreateAsync(TModel user)
        {
            throw new NotImplementedException();
        }
    }
}
