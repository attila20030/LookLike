﻿using LookLike.HttpService.Base;
using LookLike.Shared.Assemblers;
using LookLike.Shared.Dtos;
using LookLike.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LookLike.HttpService
{
    public class AdminHttpService : BaseHttpService<Admin, AdminDto>, IAdminHttpService
    {
        public AdminHttpService() { }

        public AdminHttpService(IHttpClientFactory? httpClientFactory, AdminAssembler adminAssambler) : base(httpClientFactory, adminAssambler)
        {

        }
    }
}
