﻿//using LookLike.HttpService.Base;
//using LookLike.Shared.Models;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace LookLike.HttpService
//{
//    public interface IUserHttpService : IBaseHttpService<User>
//    {
//    }
//}
